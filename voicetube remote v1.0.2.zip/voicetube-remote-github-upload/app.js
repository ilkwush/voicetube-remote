const DEFAULT_VIDEO_ID = "jNQXAC9IVRw";
const PLAYER_HOSTS = ["https://www.youtube-nocookie.com", "https://www.youtube.com"];
const playerStatus = document.querySelector("#playerStatus");
const playerOverlay = document.querySelector("#playerOverlay");
const playerFrame = document.querySelector(".player-frame");
const playerFallback = document.querySelector("#playerFallback");
const playerFallbackText = document.querySelector("#playerFallbackText");
const openOnYouTube = document.querySelector("#openOnYouTube");
const repairPlayerButton = document.querySelector("#repairPlayerButton");
const videoForm = document.querySelector("#videoForm");
const videoUrlInput = document.querySelector("#videoUrl");
const micButton = document.querySelector("#micButton");
const micButtonText = document.querySelector("#micButtonText");
const micStatus = document.querySelector("#micStatus");
const transcriptOutput = document.querySelector("#transcript");
const typedCommandForm = document.querySelector("#typedCommandForm");
const typedCommandInput = document.querySelector("#typedCommand");
const logList = document.querySelector("#logList");
const meter = document.querySelector(".meter");
const SMALL_NUMBER_WORDS = {
  zero: 0,
  one: 1,
  two: 2,
  three: 3,
  four: 4,
  five: 5,
  six: 6,
  seven: 7,
  eight: 8,
  nine: 9,
  ten: 10,
  eleven: 11,
  twelve: 12,
  thirteen: 13,
  fourteen: 14,
  fifteen: 15,
  sixteen: 16,
  seventeen: 17,
  eighteen: 18,
  nineteen: 19
};
const TENS_NUMBER_WORDS = {
  twenty: 20,
  thirty: 30,
  forty: 40,
  fourty: 40,
  fifty: 50,
  sixty: 60,
  seventy: 70,
  eighty: 80,
  ninety: 90
};

let player;
let activeVideo = getInitialVideo();
let activeHostIndex = 0;
let playerLoadTimer;
let playerReady = false;
let recognition;
let isListening = false;
let recognitionActive = false;
let lastFinalTranscript = "";

videoUrlInput.value = getYouTubeWatchUrl(activeVideo);
openOnYouTube.href = getYouTubeWatchUrl(activeVideo);

window.onYouTubeIframeAPIReady = () => {
  createPlayer();
};

function createPlayer() {
  clearTimeout(playerLoadTimer);
  playerReady = false;
  playerOverlay.classList.remove("is-hidden");
  hidePlayerFallback();
  ensurePlayerMount();

  player = new YT.Player("player", {
    host: PLAYER_HOSTS[activeHostIndex],
    videoId: activeVideo.id,
    playerVars: {
      autoplay: 0,
      controls: 1,
      modestbranding: 1,
      origin: window.location.origin,
      playsinline: 1,
      rel: 0,
      start: activeVideo.startSeconds || 0,
      widget_referrer: window.location.href
    },
    events: {
      onReady: handlePlayerReady,
      onStateChange: handlePlayerStateChange,
      onError: handlePlayerError
    }
  });

  playerLoadTimer = window.setTimeout(() => {
    if (!playerReady) {
      setStatus("Embed slow", "is-warn");
      showPlayerFallback("The YouTube embed is taking too long or was blocked. Try repairing the embed or opening the video on YouTube.");
    }
  }, 10000);
}

function ensurePlayerMount() {
  const currentMount = document.querySelector("#player");

  if (currentMount) {
    return;
  }

  const playerMount = document.createElement("div");
  playerMount.id = "player";
  playerFrame.prepend(playerMount);
}

function handlePlayerReady() {
  clearTimeout(playerLoadTimer);
  playerReady = true;
  playerOverlay.classList.add("is-hidden");
  hidePlayerFallback();
  setStatus("Ready", "is-live");
  log("Player ready");
}

function handlePlayerStateChange(event) {
  const loadedStates = [
    YT.PlayerState.UNSTARTED,
    YT.PlayerState.PLAYING,
    YT.PlayerState.PAUSED,
    YT.PlayerState.BUFFERING,
    YT.PlayerState.CUED
  ];

  if (loadedStates.includes(event.data)) {
    clearTimeout(playerLoadTimer);
    playerReady = true;
    hidePlayerFallback();
  }

  const statusByState = {
    [YT.PlayerState.UNSTARTED]: "Ready",
    [YT.PlayerState.ENDED]: "Ended",
    [YT.PlayerState.PLAYING]: "Playing",
    [YT.PlayerState.PAUSED]: "Paused",
    [YT.PlayerState.BUFFERING]: "Buffering",
    [YT.PlayerState.CUED]: "Queued"
  };
  setStatus(statusByState[event.data] || "Ready", event.data === YT.PlayerState.PLAYING ? "is-live" : "");
}

function handlePlayerError(event) {
  const message = getYouTubeErrorMessage(event.data);
  setStatus("Video error", "is-warn");
  log(message);

  if (activeHostIndex < PLAYER_HOSTS.length - 1) {
    activeHostIndex += 1;
    log("Retrying alternate YouTube embed host");
    createPlayer();
    return;
  }

  showPlayerFallback(message);
}

function setStatus(text, modifier = "") {
  playerStatus.textContent = text;
  playerStatus.className = `status-pill ${modifier}`.trim();
}

function showPlayerFallback(message) {
  playerFallbackText.textContent = message;
  openOnYouTube.href = getYouTubeWatchUrl(activeVideo);
  playerFallback.classList.remove("is-hidden");
}

function hidePlayerFallback() {
  playerFallback.classList.add("is-hidden");
}

function getYouTubeErrorMessage(code) {
  const messages = {
    2: "That YouTube URL or video ID is invalid.",
    5: "This video cannot play in the embedded HTML5 player.",
    100: "This video is private, deleted, or unavailable.",
    101: "The video owner does not allow embedding. Open it on YouTube instead.",
    150: "The video owner does not allow embedding. Open it on YouTube instead."
  };

  return messages[code] || "YouTube could not load this embed.";
}

function setupSpeechRecognition() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

  if (!SpeechRecognition) {
    micButton.disabled = true;
    micButtonText.textContent = "Use Chrome";
    transcriptOutput.textContent = "Speech recognition is unavailable here";
    setMicStatus("Open this page in Chrome or Edge for voice commands", "is-warn");
    log("Speech recognition unavailable");
    return;
  }

  if (!window.isSecureContext) {
    micButton.disabled = true;
    micButtonText.textContent = "Blocked";
    transcriptOutput.textContent = "Microphone requires a secure page";
    setMicStatus("Use http://127.0.0.1 or https for microphone access", "is-error");
    log("Microphone blocked by insecure page");
    return;
  }

  recognition = new SpeechRecognition();
  recognition.continuous = true;
  recognition.interimResults = true;
  recognition.lang = "en-US";

  recognition.addEventListener("start", () => {
    recognitionActive = true;
    setMicStatus("Listening - speak a command", "is-live");
  });

  recognition.addEventListener("audiostart", () => {
    setMicStatus("Microphone connected", "is-live");
  });

  recognition.addEventListener("speechstart", () => {
    setMicStatus("Speech detected", "is-live");
  });

  recognition.addEventListener("speechend", () => {
    setMicStatus("Processing speech", "is-live");
  });

  recognition.addEventListener("result", (event) => {
    let interim = "";

    for (let index = event.resultIndex; index < event.results.length; index += 1) {
      const result = event.results[index];
      const text = result[0].transcript.trim();

      if (result.isFinal) {
        lastFinalTranscript = text;
        transcriptOutput.textContent = text;
        setMicStatus(`Heard: ${text}`, "is-live");
        runCommand(text);
      } else {
        interim = text;
      }
    }

    if (interim) {
      transcriptOutput.textContent = interim;
      setMicStatus(`Hearing: ${interim}`, "is-live");
    }
  });

  recognition.addEventListener("nomatch", () => {
    setMicStatus("I heard sound, but not a command", "is-warn");
    log("Speech did not match a command");
  });

  recognition.addEventListener("end", () => {
    recognitionActive = false;
    if (isListening) {
      try {
        recognition.start();
      } catch (error) {
        stopListening({ skipStop: true, status: "Speech service stopped unexpectedly" });
      }
    }
  });

  recognition.addEventListener("error", (event) => {
    log(`Speech error: ${event.error}`);

    const fatalErrors = ["not-allowed", "service-not-allowed", "audio-capture", "language-not-supported"];
    setMicStatus(getSpeechErrorMessage(event.error), getSpeechErrorLevel(event.error));

    if (event.error === "no-speech") {
      transcriptOutput.textContent = "No speech heard";
      return;
    }

    if (fatalErrors.includes(event.error)) {
      stopListening({ skipStop: true, status: getSpeechErrorMessage(event.error) });
      transcriptOutput.textContent = getSpeechErrorMessage(event.error);
    }
  });

  updateMicrophonePermissionStatus();
}

async function toggleListening() {
  if (!recognition) {
    return;
  }

  if (isListening) {
    stopListening();
    return;
  }

  const hasMicrophone = await requestMicrophoneAccess();
  if (!hasMicrophone) {
    return;
  }

  isListening = true;
  lastFinalTranscript = "";
  micButton.classList.add("is-listening");
  micButton.setAttribute("aria-pressed", "true");
  micButtonText.textContent = "Stop";
  meter.classList.add("is-active");
  transcriptOutput.textContent = "Listening";

  try {
    recognition.start();
    log("Listening started");
  } catch (error) {
    setMicStatus("Listening is already active", "is-warn");
    log(`Listening could not start: ${error.name || error.message || "already active"}`);
  }
}

function stopListening(options = {}) {
  isListening = false;
  micButton.classList.remove("is-listening");
  micButton.setAttribute("aria-pressed", "false");
  micButtonText.textContent = "Start";
  meter.classList.remove("is-active");

  if (recognition && recognitionActive && !options.skipStop) {
    recognition.stop();
  }

  if (!lastFinalTranscript) {
    transcriptOutput.textContent = options.status || "Waiting for a command";
  }

  setMicStatus(options.status || "Microphone idle", options.status ? "is-warn" : "");
  log(options.status ? `Listening stopped: ${options.status}` : "Listening stopped");
}

async function requestMicrophoneAccess() {
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    setMicStatus("Microphone access is unavailable in this browser", "is-error");
    transcriptOutput.textContent = "Microphone access unavailable";
    log("getUserMedia unavailable");
    return false;
  }

  setMicStatus("Waiting for microphone permission", "is-warn");

  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    stream.getTracks().forEach((track) => track.stop());
    setMicStatus("Microphone ready", "is-live");
    return true;
  } catch (error) {
    const message = getMicrophoneErrorMessage(error);
    setMicStatus(message, "is-error");
    transcriptOutput.textContent = message;
    log(`Microphone error: ${error.name || error.message || "unknown"}`);
    return false;
  }
}

async function updateMicrophonePermissionStatus() {
  if (!navigator.permissions || !navigator.permissions.query) {
    setMicStatus("Microphone idle", "");
    return;
  }

  try {
    const permissionStatus = await navigator.permissions.query({ name: "microphone" });
    setPermissionStatusMessage(permissionStatus.state);
    permissionStatus.addEventListener("change", () => setPermissionStatusMessage(permissionStatus.state));
  } catch (error) {
    setMicStatus("Microphone idle", "");
  }
}

function setPermissionStatusMessage(state) {
  if (state === "granted") {
    setMicStatus("Microphone permission granted", "is-live");
  } else if (state === "denied") {
    setMicStatus("Microphone permission blocked", "is-error");
  } else {
    setMicStatus("Click Start and allow microphone access", "");
  }
}

function setMicStatus(text, modifier = "") {
  micStatus.textContent = text;
  micStatus.className = `mic-status ${modifier}`.trim();
}

function getMicrophoneErrorMessage(error) {
  const name = error.name || "";

  if (name === "NotAllowedError" || name === "SecurityError") {
    return "Microphone permission is blocked";
  }

  if (name === "NotFoundError" || name === "DevicesNotFoundError") {
    return "No microphone was found";
  }

  if (name === "NotReadableError" || name === "TrackStartError") {
    return "Microphone is busy in another app";
  }

  if (name === "OverconstrainedError") {
    return "Microphone settings are not supported";
  }

  return "Microphone could not start";
}

function getSpeechErrorMessage(error) {
  const messages = {
    "aborted": "Speech listening was interrupted",
    "audio-capture": "No microphone audio was captured",
    "bad-grammar": "Speech grammar error",
    "language-not-supported": "Speech language is not supported",
    "network": "Speech service needs a working internet connection",
    "no-speech": "No speech heard - try again",
    "not-allowed": "Microphone permission is blocked",
    "service-not-allowed": "Speech service is blocked"
  };

  return messages[error] || `Speech error: ${error}`;
}

function getSpeechErrorLevel(error) {
  return error === "no-speech" || error === "aborted" ? "is-warn" : "is-error";
}

function runCommand(rawCommand) {
  const command = rawCommand.toLowerCase().replace(/[^\w\s:/.-]/g, "").trim();

  if (!command) {
    return;
  }

  const result = parseCommand(command);

  if (!result) {
    setMicStatus(`Command not recognized: ${rawCommand}`, "is-warn");
    log(`Ignored: ${rawCommand}`);
    return;
  }

  result.action();
  log(result.label);
}

function parseCommand(command) {
  if (!player || typeof player.playVideo !== "function") {
    return {
      label: "Player is still loading",
      action: () => setStatus("Player loading", "is-warn")
    };
  }

  const loadMatch = command.match(/(?:load|open|play video)\s+(.+)/);
  if (loadMatch) {
    const video = parseVideoInput(loadMatch[1]);
    if (video) {
      return { label: `Load ${video.id}`, action: () => loadVideo(video) };
    }
  }

  if (matches(command, ["play", "resume", "start video"])) {
    return { label: "Play", action: () => player.playVideo() };
  }

  if (matches(command, ["pause", "hold", "stop video"])) {
    return { label: "Pause", action: () => player.pauseVideo() };
  }

  if (matches(command, ["mute", "silent"])) {
    return { label: "Mute", action: () => player.mute() };
  }

  if (matches(command, ["unmute", "sound on"])) {
    return { label: "Unmute", action: () => player.unMute() };
  }

  if (matches(command, ["restart", "start over", "beginning"])) {
    return { label: "Restart", action: () => seekTo(0) };
  }

  if (matches(command, ["faster", "speed up"])) {
    return { label: "Speed up", action: () => changePlaybackRate(0.25) };
  }

  if (matches(command, ["slower", "slow down"])) {
    return { label: "Slow down", action: () => changePlaybackRate(-0.25) };
  }

  if (matches(command, ["normal speed", "regular speed"])) {
    return { label: "Normal speed", action: () => player.setPlaybackRate(1) };
  }

  if (command.includes("volume up") || command.includes("louder")) {
    return { label: "Volume up", action: () => changeVolume(10) };
  }

  if (command.includes("volume down") || command.includes("quieter")) {
    return { label: "Volume down", action: () => changeVolume(-10) };
  }

  const volumeMatch = command.match(/(?:volume|sound)\s*(?:to|at)?\s*([a-z\d -]+)/);
  if (volumeMatch) {
    const parsedVolume = parseSpokenNumber(volumeMatch[1]);
    if (parsedVolume !== null) {
      const volume = clamp(parsedVolume, 0, 100);
      return { label: `Volume ${volume}`, action: () => player.setVolume(volume) };
    }
  }

  const forwardMatch = command.match(/(?:forward|ahead|skip)(?:\s+([a-z\d -]+))?/);
  if (forwardMatch) {
    const seconds = parseSpokenNumber(forwardMatch[1]) || 10;
    return { label: `Forward ${seconds}s`, action: () => seekBy(seconds) };
  }

  const backMatch = command.match(/(?:back|rewind|backward)(?:\s+([a-z\d -]+))?/);
  if (backMatch) {
    const seconds = parseSpokenNumber(backMatch[1]) || 10;
    return { label: `Back ${seconds}s`, action: () => seekBy(-seconds) };
  }

  const seekMatch = command.match(/(?:go to|jump to|seek to)\s+(.+)/);
  if (seekMatch) {
    const seconds = parseTime(seekMatch[1]);
    if (seconds !== null) {
      return { label: `Seek ${formatTime(seconds)}`, action: () => seekTo(seconds) };
    }
  }

  return null;
}

function matches(command, phrases) {
  return phrases.some((phrase) => command === phrase || command.includes(phrase));
}

function seekBy(delta) {
  const currentTime = Number(player.getCurrentTime() || 0);
  const duration = Number(player.getDuration() || 0);
  seekTo(clamp(currentTime + delta, 0, duration || currentTime + delta));
}

function seekTo(seconds) {
  player.seekTo(Math.max(0, seconds), true);
}

function changeVolume(delta) {
  const nextVolume = clamp(Number(player.getVolume() || 0) + delta, 0, 100);
  player.unMute();
  player.setVolume(nextVolume);
}

function changePlaybackRate(delta) {
  const rates = player.getAvailablePlaybackRates();
  const current = Number(player.getPlaybackRate() || 1);
  const target = current + delta;
  const nearest = rates.reduce((best, rate) => {
    return Math.abs(rate - target) < Math.abs(best - target) ? rate : best;
  }, rates[0]);
  player.setPlaybackRate(nearest);
}

function parseTime(value) {
  if (!value) {
    return null;
  }

  const cleanValue = value.trim();
  const colonParts = cleanValue.split(":").map(Number);

  if (colonParts.length > 1 && colonParts.every((part) => Number.isFinite(part))) {
    return colonParts.reduce((total, part) => total * 60 + part, 0);
  }

  const minuteSecondMatch = cleanValue.match(/(?:(\d+)\s*(?:minutes?|mins?|m))?\s*(?:(\d+)\s*(?:seconds?|secs?|s))?/);
  if (minuteSecondMatch && (minuteSecondMatch[1] || minuteSecondMatch[2])) {
    return Number(minuteSecondMatch[1] || 0) * 60 + Number(minuteSecondMatch[2] || 0);
  }

  const spokenMinuteSecondMatch = cleanValue.match(/(?:(.+?)\s*(?:minutes?|mins?|m))?\s*(?:(.+?)\s*(?:seconds?|secs?|s))?$/);
  if (spokenMinuteSecondMatch && (spokenMinuteSecondMatch[1] || spokenMinuteSecondMatch[2])) {
    const minutes = parseSpokenNumber(spokenMinuteSecondMatch[1]) || 0;
    const seconds = parseSpokenNumber(spokenMinuteSecondMatch[2]) || 0;
    return minutes * 60 + seconds;
  }

  const numeric = Number(cleanValue);
  if (Number.isFinite(numeric)) {
    return numeric;
  }

  return parseSpokenNumber(cleanValue);
}

function parseSpokenNumber(value) {
  if (!value) {
    return null;
  }

  const cleanValue = String(value).toLowerCase().replace(/-/g, " ").replace(/\band\b/g, " ").trim();
  const numeric = Number(cleanValue);
  if (Number.isFinite(numeric)) {
    return numeric;
  }

  const words = cleanValue.split(/\s+/).filter(Boolean);
  if (!words.length) {
    return null;
  }

  let total = 0;
  let current = 0;
  let matched = false;

  words.forEach((word) => {
    if (Object.prototype.hasOwnProperty.call(SMALL_NUMBER_WORDS, word)) {
      current += SMALL_NUMBER_WORDS[word];
      matched = true;
    } else if (Object.prototype.hasOwnProperty.call(TENS_NUMBER_WORDS, word)) {
      current += TENS_NUMBER_WORDS[word];
      matched = true;
    } else if (word === "hundred") {
      current = (current || 1) * 100;
      matched = true;
    }
  });

  total += current;
  return matched ? total : null;
}

function formatTime(totalSeconds) {
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = Math.floor(totalSeconds % 60).toString().padStart(2, "0");
  return `${minutes}:${seconds}`;
}

function parseVideoInput(input) {
  const value = input.trim();

  if (/^[a-zA-Z0-9_-]{11}$/.test(value)) {
    return { id: value, startSeconds: 0 };
  }

  try {
    const url = new URL(value);
    let id = null;

    if (url.hostname.includes("youtu.be")) {
      id = url.pathname.split("/").filter(Boolean)[0] || null;
    } else if (url.searchParams.has("v")) {
      id = url.searchParams.get("v");
    } else {
      const pathMatch = url.pathname.match(/\/(?:embed|shorts|live)\/([a-zA-Z0-9_-]{11})/);
      id = pathMatch ? pathMatch[1] : null;
    }

    return id ? { id, startSeconds: parseStartSeconds(url) } : null;
  } catch (error) {
    return null;
  }
}

function getInitialVideo() {
  const params = new URLSearchParams(window.location.search);
  const directVideo = params.get("video") || params.get("url") || params.get("v");

  if (directVideo) {
    const video = parseVideoInput(directVideo);
    if (video) {
      video.startSeconds = video.startSeconds || parseTime(params.get("t") || params.get("start")) || 0;
      return video;
    }
  }

  return { id: DEFAULT_VIDEO_ID, startSeconds: 0 };
}

function parseStartSeconds(url) {
  const rawStart = url.searchParams.get("start") || url.searchParams.get("t") || "";
  const hashStart = url.hash.startsWith("#t=") ? url.hash.slice(3) : "";
  return parseTime(rawStart || hashStart) || 0;
}

function getYouTubeWatchUrl(video = activeVideo) {
  const url = new URL(`https://www.youtube.com/watch?v=${video.id}`);

  if (video.startSeconds) {
    url.searchParams.set("t", `${Math.floor(video.startSeconds)}s`);
  }

  return url.toString();
}

function loadVideo(video) {
  activeVideo = video;
  activeHostIndex = 0;
  playerReady = false;
  videoUrlInput.value = getYouTubeWatchUrl(video);
  openOnYouTube.href = getYouTubeWatchUrl(video);
  hidePlayerFallback();
  clearTimeout(playerLoadTimer);

  if (player && typeof player.loadVideoById === "function") {
    playerOverlay.classList.add("is-hidden");
    player.loadVideoById({
      videoId: video.id,
      startSeconds: video.startSeconds || 0
    });
    playerLoadTimer = window.setTimeout(() => {
      if (!playerReady) {
        showPlayerFallback("The YouTube embed did not confirm it loaded. If the video panel shows a config error, use Repair embed or Open on YouTube.");
      }
    }, 8000);
    return;
  }

  createPlayer();
}

function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

function log(message) {
  const item = document.createElement("li");
  const time = document.createElement("time");
  const text = document.createElement("span");
  const now = new Date();

  time.textContent = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
  text.textContent = message;
  item.append(time, text);
  logList.prepend(item);

  while (logList.children.length > 8) {
    logList.lastElementChild.remove();
  }
}

videoForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const video = parseVideoInput(videoUrlInput.value);

  if (!video) {
    log("Enter a valid YouTube URL or ID");
    setStatus("Invalid video", "is-warn");
    return;
  }

  loadVideo(video);
});

repairPlayerButton.addEventListener("click", () => {
  activeHostIndex = (activeHostIndex + 1) % PLAYER_HOSTS.length;

  if (player && typeof player.destroy === "function") {
    try {
      player.destroy();
    } catch (error) {
      log("Could not destroy old player cleanly");
    }
  }

  player = null;
  createPlayer();
  log("Repairing embed");
});

typedCommandForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const command = typedCommandInput.value.trim();

  if (command) {
    transcriptOutput.textContent = command;
    runCommand(command);
    typedCommandInput.value = "";
  }
});

document.addEventListener("click", (event) => {
  const button = event.target.closest("[data-command]");
  if (!button) {
    return;
  }

  const command = button.dataset.command;
  transcriptOutput.textContent = command;
  runCommand(command);
});

micButton.addEventListener("click", toggleListening);
setupSpeechRecognition();
