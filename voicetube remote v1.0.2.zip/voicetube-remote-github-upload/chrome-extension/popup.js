const micButton = document.querySelector("#micButton");
const micButtonText = document.querySelector("#micButtonText");
const openRemoteButton = document.querySelector("#openRemoteButton");
const statusOutput = document.querySelector("#status");
const transcriptOutput = document.querySelector("#transcript");
const typedCommandForm = document.querySelector("#typedCommandForm");
const typedCommandInput = document.querySelector("#typedCommand");
const commandBank = document.querySelector(".command-bank");
const logList = document.querySelector("#logList");
const meter = document.querySelector(".meter");
const targetTitle = document.querySelector("#targetTitle");
const targetMeta = document.querySelector("#targetMeta");
const commandParser = window.VoiceTubeCommands;

const SMALL_NUMBER_WORDS = {
  zero: 0,
  one: 1,
  two: 2,
  three: 3,
  four: 4,
  five: 5,
  six: 6,
  seven: 7,
  eight: 8,
  nine: 9,
  ten: 10,
  eleven: 11,
  twelve: 12,
  thirteen: 13,
  fourteen: 14,
  fifteen: 15,
  sixteen: 16,
  seventeen: 17,
  eighteen: 18,
  nineteen: 19
};

const TENS_NUMBER_WORDS = {
  twenty: 20,
  thirty: 30,
  forty: 40,
  fourty: 40,
  fifty: 50,
  sixty: 60,
  seventy: 70,
  eighty: 80,
  ninety: 90
};

const YOUTUBE_URL_PATTERNS = [
  "https://*.youtube.com/*",
  "https://youtu.be/*"
];

let recognition;
let recognitionActive = false;
let isListening = false;
let lastFinalTranscript = "";
let targetTab = null;
const isPopup = location.pathname.endsWith("/popup.html");

init();

async function init() {
  setupSpeechRecognition();
  await refreshTarget();
}

async function refreshTarget() {
  targetTab = await findYouTubeTab();

  if (!targetTab) {
    targetTitle.textContent = "No YouTube tab found";
    targetMeta.textContent = "Open a YouTube video tab, then reopen this popup.";
    setStatus("No YouTube video tab detected", "is-warn");
    return;
  }

  try {
    const response = await sendToYouTubeTab({ type: "GET_STATE" });
    renderTarget(response.state);
  } catch (error) {
    targetTitle.textContent = cleanTitle(targetTab.title || "YouTube tab");
    targetMeta.textContent = targetTab.url || "YouTube tab found";
    setStatus(error.message || "YouTube tab found, but the page is not ready", "is-warn");
  }
}

function setupSpeechRecognition() {
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

  if (!SpeechRecognition) {
    micButton.disabled = true;
    micButtonText.textContent = "No voice";
    transcriptOutput.textContent = "Speech recognition is unavailable in this browser";
    setStatus("Use Chrome with speech recognition enabled", "is-error");
    log("Speech recognition unavailable");
    return;
  }

  recognition = new SpeechRecognition();
  recognition.continuous = true;
  recognition.interimResults = true;
  recognition.lang = "en-US";

  recognition.addEventListener("start", () => {
    recognitionActive = true;
    setStatus("Listening - speak a command", "is-live");
  });

  recognition.addEventListener("audiostart", () => {
    setStatus("Microphone connected", "is-live");
  });

  recognition.addEventListener("speechstart", () => {
    setStatus("Speech detected", "is-live");
  });

  recognition.addEventListener("speechend", () => {
    setStatus("Processing speech", "is-live");
  });

  recognition.addEventListener("result", (event) => {
    let interim = "";

    for (let index = event.resultIndex; index < event.results.length; index += 1) {
      const result = event.results[index];
      const text = result[0].transcript.trim();

      if (result.isFinal) {
        lastFinalTranscript = text;
        transcriptOutput.textContent = text;
        setStatus(`Heard: ${text}`, "is-live");
        runCommand(text);
      } else {
        interim = text;
      }
    }

    if (interim) {
      transcriptOutput.textContent = interim;
      setStatus(`Hearing: ${interim}`, "is-live");
    }
  });

  recognition.addEventListener("nomatch", () => {
    setStatus("I heard sound, but not a command", "is-warn");
    log("Speech did not match a command");
  });

  recognition.addEventListener("end", () => {
    recognitionActive = false;

    if (isListening) {
      try {
        recognition.start();
      } catch (error) {
        stopListening("Speech service stopped unexpectedly");
      }
    }
  });

  recognition.addEventListener("error", (event) => {
    const message = getSpeechErrorMessage(event.error);
    setStatus(message, getSpeechErrorLevel(event.error));
    log(`Speech error: ${event.error}`);

    if (event.error === "no-speech") {
      transcriptOutput.textContent = "No speech heard";
      return;
    }

    if (["not-allowed", "service-not-allowed", "audio-capture", "language-not-supported"].includes(event.error)) {
      stopListening(message);
      transcriptOutput.textContent = message;
    }
  });
}

async function toggleListening() {
  if (!recognition) {
    return;
  }

  if (isListening) {
    stopListening();
    return;
  }

  const ready = await requestMicrophoneAccess();
  if (!ready) {
    return;
  }

  await refreshTarget();
  isListening = true;
  lastFinalTranscript = "";
  micButton.classList.add("is-listening");
  micButton.setAttribute("aria-pressed", "true");
  micButtonText.textContent = "Stop";
  meter.classList.add("is-active");
  transcriptOutput.textContent = "Listening";

  try {
    recognition.start();
    log("Listening started");
  } catch (error) {
    setStatus("Listening is already active", "is-warn");
    log("Listening is already active");
  }
}

function stopListening(status = "") {
  isListening = false;
  micButton.classList.remove("is-listening");
  micButton.setAttribute("aria-pressed", "false");
  micButtonText.textContent = "Start";
  meter.classList.remove("is-active");

  if (recognition && recognitionActive) {
    recognition.stop();
  }

  if (!lastFinalTranscript) {
    transcriptOutput.textContent = status || "Waiting for a command";
  }

  setStatus(status || "Microphone idle", status ? "is-warn" : "");
  log(status ? `Listening stopped: ${status}` : "Listening stopped");
}

async function requestMicrophoneAccess() {
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    setStatus("Microphone access is unavailable", "is-error");
    transcriptOutput.textContent = "Microphone access unavailable";
    log("getUserMedia unavailable");
    return false;
  }

  setStatus("Waiting for microphone permission", "is-warn");

  try {
    const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    stream.getTracks().forEach((track) => track.stop());
    setStatus("Microphone ready", "is-live");
    return true;
  } catch (error) {
    const message = getMicrophoneErrorMessage(error);
    setStatus(message, "is-error");
    transcriptOutput.textContent = message;
    log(`Microphone error: ${error.name || error.message || "unknown"}`);

    if (isPopup && (error.name === "NotAllowedError" || error.name === "SecurityError")) {
      await openRemotePage("Microphone was blocked in the popup. Use the full remote tab and allow microphone access there.");
    }

    return false;
  }
}

async function openRemotePage(message = "") {
  const url = chrome.runtime.getURL("remote.html");
  await chrome.tabs.create({ url });

  if (message) {
    setStatus(message, "is-warn");
    log(message);
  }
}

async function runCommand(rawCommand) {
  const command = rawCommand.toLowerCase().replace(/[^\w\s:/.-]/g, "").trim();
  const action = parseCommand(command);

  if (!action) {
    setStatus(`Command not recognized: ${rawCommand}`, "is-warn");
    log(`Ignored: ${rawCommand}`);
    return;
  }

  if (action.type === "playSearch") {
    await playSearch(action.query);
    return;
  }

  if (action.type === "browserBack") {
    await browserBack(action.label);
    return;
  }

  if (action.type === "navigate") {
    await navigateTarget(action.url, action.label);
    return;
  }

  try {
    const response = await sendToYouTubeTab({
      type: "RUN_ACTION",
      action
    });

    renderTarget(response.state);
    setStatus(response.result || action.label, "is-live");
    log(response.result || action.label);
  } catch (error) {
    setStatus(error.message || "Could not control YouTube", "is-error");
    log(error.message || "Command failed");
  }
}

function parseCommand(command) {
  return commandParser.parseVoiceCommand(command);
}

async function navigateTarget(url, label, options = {}) {
  const tab = await findYouTubeTab();
  let navigatedTab;

  if (tab) {
    navigatedTab = await chrome.tabs.update(tab.id, { url, active: true });
    targetTab = navigatedTab;
  } else {
    navigatedTab = await chrome.tabs.create({ url });
    targetTab = navigatedTab;
  }

  setStatus(label, "is-live");
  log(label);
  window.setTimeout(refreshTarget, options.refreshDelay ?? 1200);
  return navigatedTab;
}

async function playSearch(query) {
  const tab = await navigateTarget(getYouTubeSearchUrl(query), `Search: ${query}`, { refreshDelay: 400 });

  window.setTimeout(async () => {
    try {
      await ensureContentScript(tab.id);
      const response = await chrome.tabs.sendMessage(tab.id, {
        source: "voicetube-remote",
        type: "RUN_ACTION",
        action: { type: "playFirstResult" }
      });
      setStatus(`Playing: ${query}`, "is-live");
      log(response.result || `Playing: ${query}`);
      window.setTimeout(refreshTarget, 1400);
    } catch (error) {
      setStatus(`Search opened: ${query}`, "is-warn");
      log(error.message || "Could not open first result");
      refreshTarget();
    }
  }, 1800);
}

async function browserBack(label) {
  const tab = await getTargetOrThrow();

  try {
    await chrome.tabs.goBack(tab.id);
    setStatus(label, "is-live");
    log(label);
    window.setTimeout(refreshTarget, 1000);
  } catch (error) {
    try {
      const response = await sendToYouTubeTab({
        type: "RUN_ACTION",
        action: { type: "previousVideo" }
      });
      renderTarget(response.state);
      setStatus(response.result || label, "is-live");
      log(response.result || label);
    } catch (fallbackError) {
      setStatus("No previous page for this tab", "is-warn");
      log("No previous page for this tab");
    }
  }
}

async function sendToYouTubeTab(message) {
  const tab = await getTargetOrThrow();
  await ensureContentScript(tab.id);

  return await chrome.tabs.sendMessage(tab.id, {
    source: "voicetube-remote",
    ...message
  });
}

async function ensureContentScript(tabId) {
  try {
    await chrome.tabs.sendMessage(tabId, {
      source: "voicetube-remote",
      type: "PING"
    });
    return;
  } catch (error) {
    await chrome.scripting.executeScript({
      target: { tabId },
      files: ["content.js"]
    });
  }
}

async function getTargetOrThrow() {
  targetTab = await findYouTubeTab();

  if (!targetTab) {
    throw new Error("Open a YouTube video tab first");
  }

  return targetTab;
}

async function findYouTubeTab() {
  const activeTabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const activeTab = activeTabs[0] || null;

  if (activeTab && isYouTubeUrl(activeTab.url)) {
    return activeTab;
  }

  const youtubeTabs = await chrome.tabs.query({ url: YOUTUBE_URL_PATTERNS });
  return youtubeTabs.sort((a, b) => {
    if (a.active !== b.active) {
      return a.active ? -1 : 1;
    }

    return (b.lastAccessed || 0) - (a.lastAccessed || 0);
  })[0] || null;
}

function isYouTubeUrl(url) {
  if (!url) {
    return false;
  }

  try {
    const parsed = new URL(url);
    return parsed.hostname.endsWith("youtube.com") || parsed.hostname === "youtu.be";
  } catch (error) {
    return false;
  }
}

function renderTarget(state) {
  if (!state) {
    return;
  }

  targetTitle.textContent = state.title || cleanTitle(targetTab?.title || "YouTube video");
  targetMeta.textContent = [
    state.videoId ? `ID ${state.videoId}` : "YouTube",
    `${formatTime(state.currentTime || 0)} / ${formatTime(state.duration || 0)}`,
    `Vol ${state.volume ?? 0}`,
    `${state.playbackRate || 1}x`
  ].join("  |  ");
}

function cleanTitle(title) {
  return title.replace(/\s*-\s*YouTube\s*$/i, "").trim();
}

function parseVideoInput(input) {
  const value = input.trim();

  if (/^[a-zA-Z0-9_-]{11}$/.test(value)) {
    return { id: value, startSeconds: 0 };
  }

  try {
    const url = new URL(value);
    let id = null;

    if (url.hostname.includes("youtu.be")) {
      id = url.pathname.split("/").filter(Boolean)[0] || null;
    } else if (url.searchParams.has("v")) {
      id = url.searchParams.get("v");
    } else {
      const pathMatch = url.pathname.match(/\/(?:embed|shorts|live)\/([a-zA-Z0-9_-]{11})/);
      id = pathMatch ? pathMatch[1] : null;
    }

    return id ? { id, startSeconds: parseStartSeconds(url) } : null;
  } catch (error) {
    return null;
  }
}

function parseStartSeconds(url) {
  const rawStart = url.searchParams.get("start") || url.searchParams.get("t") || "";
  const hashStart = url.hash.startsWith("#t=") ? url.hash.slice(3) : "";
  return parseTime(rawStart || hashStart) || 0;
}

function getYouTubeWatchUrl(video) {
  const url = new URL(`https://www.youtube.com/watch?v=${video.id}`);

  if (video.startSeconds) {
    url.searchParams.set("t", `${Math.floor(video.startSeconds)}s`);
  }

  return url.toString();
}

function getYouTubeSearchUrl(query) {
  const url = new URL("https://www.youtube.com/results");
  url.searchParams.set("search_query", query);
  return url.toString();
}

function cleanSearchQuery(query) {
  return query
    .replace(/\b(on youtube|youtube|please)\b/gi, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function parseTime(value) {
  if (!value) {
    return null;
  }

  const cleanValue = String(value).trim();
  const colonParts = cleanValue.split(":").map(Number);

  if (colonParts.length > 1 && colonParts.every((part) => Number.isFinite(part))) {
    return colonParts.reduce((total, part) => total * 60 + part, 0);
  }

  const minuteSecondMatch = cleanValue.match(/(?:(\d+)\s*(?:hours?|hrs?|h))?\s*(?:(\d+)\s*(?:minutes?|mins?|m))?\s*(?:(\d+)\s*(?:seconds?|secs?|s))?/);
  if (minuteSecondMatch && (minuteSecondMatch[1] || minuteSecondMatch[2] || minuteSecondMatch[3])) {
    return Number(minuteSecondMatch[1] || 0) * 3600 +
      Number(minuteSecondMatch[2] || 0) * 60 +
      Number(minuteSecondMatch[3] || 0);
  }

  const numeric = Number(cleanValue);
  if (Number.isFinite(numeric)) {
    return numeric;
  }

  return parseSpokenNumber(cleanValue);
}

function parseSpokenNumber(value) {
  if (!value) {
    return null;
  }

  const cleanValue = String(value).toLowerCase().replace(/-/g, " ").replace(/\band\b/g, " ").trim();
  const numeric = Number(cleanValue);
  if (Number.isFinite(numeric)) {
    return numeric;
  }

  const words = cleanValue.split(/\s+/).filter(Boolean);
  if (!words.length) {
    return null;
  }

  let current = 0;
  let matched = false;

  words.forEach((word) => {
    if (Object.prototype.hasOwnProperty.call(SMALL_NUMBER_WORDS, word)) {
      current += SMALL_NUMBER_WORDS[word];
      matched = true;
    } else if (Object.prototype.hasOwnProperty.call(TENS_NUMBER_WORDS, word)) {
      current += TENS_NUMBER_WORDS[word];
      matched = true;
    } else if (word === "hundred") {
      current = (current || 1) * 100;
      matched = true;
    }
  });

  return matched ? current : null;
}

function matches(command, phrases) {
  return phrases.some((phrase) => command === phrase || command.includes(phrase));
}

function matchesExact(command, phrases) {
  return phrases.some((phrase) => command === phrase);
}

function formatTime(totalSeconds) {
  const cleanSeconds = Math.max(0, Number(totalSeconds) || 0);
  const hours = Math.floor(cleanSeconds / 3600);
  const minutes = Math.floor((cleanSeconds % 3600) / 60);
  const seconds = Math.floor(cleanSeconds % 60).toString().padStart(2, "0");

  if (hours) {
    return `${hours}:${minutes.toString().padStart(2, "0")}:${seconds}`;
  }

  return `${minutes}:${seconds}`;
}

function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}

function getMicrophoneErrorMessage(error) {
  const name = error.name || "";

  if (name === "NotAllowedError" || name === "SecurityError") {
    return "Microphone permission is blocked";
  }

  if (name === "NotFoundError" || name === "DevicesNotFoundError") {
    return "No microphone was found";
  }

  if (name === "NotReadableError" || name === "TrackStartError") {
    return "Microphone is busy in another app";
  }

  return "Microphone could not start";
}

function getSpeechErrorMessage(error) {
  const messages = {
    "aborted": "Speech listening was interrupted",
    "audio-capture": "No microphone audio was captured",
    "bad-grammar": "Speech grammar error",
    "language-not-supported": "Speech language is not supported",
    "network": "Speech service needs a working internet connection",
    "no-speech": "No speech heard - try again",
    "not-allowed": "Microphone permission is blocked",
    "service-not-allowed": "Speech service is blocked"
  };

  return messages[error] || `Speech error: ${error}`;
}

function getSpeechErrorLevel(error) {
  return error === "no-speech" || error === "aborted" ? "is-warn" : "is-error";
}

function setStatus(text, modifier = "") {
  statusOutput.textContent = text;
  statusOutput.className = `status ${modifier}`.trim();
}

function log(message) {
  const item = document.createElement("li");
  const time = document.createElement("time");
  const text = document.createElement("span");
  const now = new Date();

  time.textContent = now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
  text.textContent = message;
  item.append(time, text);
  logList.prepend(item);

  while (logList.children.length > 7) {
    logList.lastElementChild.remove();
  }
}

typedCommandForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const command = typedCommandInput.value.trim();

  if (command) {
    transcriptOutput.textContent = command;
    runCommand(command);
    typedCommandInput.value = "";
  }
});

commandBank.addEventListener("click", (event) => {
  const button = event.target.closest("[data-command]");

  if (!button) {
    return;
  }

  transcriptOutput.textContent = button.dataset.command;
  runCommand(button.dataset.command);
});

micButton.addEventListener("click", toggleListening);

if (openRemoteButton) {
  openRemoteButton.addEventListener("click", () => {
    openRemotePage("Opened full remote tab");
  });
}
