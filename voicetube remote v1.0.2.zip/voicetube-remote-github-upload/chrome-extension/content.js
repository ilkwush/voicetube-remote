(() => {
  if (window.__voiceTubeRemoteInstalled) {
    return;
  }

  window.__voiceTubeRemoteInstalled = true;
  let loopVideo = null;
  let loopReplayHandler = null;

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || message.source !== "voicetube-remote") {
      return false;
    }

    (async () => {
      try {
        if (message.type === "PING") {
          sendResponse({ ok: true, state: getVideoState() });
          return;
        }

        if (message.type === "GET_STATE") {
          sendResponse({ ok: true, state: getVideoState() });
          return;
        }

        if (message.type === "RUN_ACTION") {
          const result = await runAction(message.action);
          sendResponse({ ok: true, result, state: getVideoState() });
          return;
        }
      } catch (error) {
        sendResponse({
          ok: false,
          error: error.message || "Could not control this YouTube tab"
        });
      }
    })();

    return true;
  });

  async function runAction(action) {
    if (action.type === "nextVideo") {
      await clickPlayerButton([".ytp-next-button", "a.ytp-next-button"]);
      return "Next video";
    }

    if (action.type === "previousVideo") {
      const clicked = await clickPlayerButton([".ytp-prev-button", ".ytp-previous-button"], { optional: true });

      if (!clicked) {
        history.back();
      }

      return clicked ? "Previous video" : "Back to previous page";
    }

    if (action.type === "playFirstResult") {
      await clickFirstVideoResult();
      return "Playing first result";
    }

    if (action.type === "comment") {
      await draftComment(action.text);
      return "Comment draft ready";
    }

    if (action.type === "setReaction") {
      return await setReaction(action.reaction);
    }

    if (action.type === "subscription") {
      return await setSubscription(action.enabled);
    }

    const video = getVideo();

    if (!video) {
      throw new Error("No YouTube video player found");
    }

    if (action.type === "play") {
      await playVideo(video);
      return "Play";
    }

    if (action.type === "pause") {
      video.pause();
      return "Pause";
    }

    if (action.type === "toggle") {
      if (video.paused) {
        await playVideo(video);
        return "Play";
      }

      video.pause();
      return "Pause";
    }

    if (action.type === "restart") {
      video.currentTime = 0;
      await playVideo(video);
      return "Restart";
    }

    if (action.type === "seekBy") {
      video.currentTime = clamp(video.currentTime + action.seconds, 0, getDuration(video));
      return `${action.seconds >= 0 ? "Forward" : "Back"} ${Math.abs(action.seconds)}s`;
    }

    if (action.type === "seekTo") {
      video.currentTime = clamp(action.seconds, 0, getDuration(video));
      return `Seek ${formatTime(action.seconds)}`;
    }

    if (action.type === "mute") {
      video.muted = true;
      return "Mute";
    }

    if (action.type === "unmute") {
      video.muted = false;
      return "Unmute";
    }

    if (action.type === "volumeBy") {
      video.muted = false;
      video.volume = clamp(video.volume + action.delta, 0, 1);
      return `Volume ${Math.round(video.volume * 100)}`;
    }

    if (action.type === "volumeTo") {
      video.muted = false;
      video.volume = clamp(action.volume / 100, 0, 1);
      return `Volume ${Math.round(video.volume * 100)}`;
    }

    if (action.type === "rateBy") {
      video.playbackRate = clamp(Math.round((video.playbackRate + action.delta) * 4) / 4, 0.25, 2);
      return `Speed ${video.playbackRate}x`;
    }

    if (action.type === "rateTo") {
      video.playbackRate = clamp(action.rate, 0.25, 2);
      return `Speed ${video.playbackRate}x`;
    }

    if (action.type === "fullscreen") {
      return await setFullscreen(action.enabled);
    }

    if (action.type === "loop") {
      setLoop(video, action.enabled);
      return action.enabled ? "Loop on" : "Loop off";
    }

    if (action.type === "captions") {
      return await setCaptions(action.enabled);
    }

    throw new Error("Unsupported command");
  }

  async function playVideo(video) {
    try {
      await video.play();
    } catch (error) {
      const playButton = document.querySelector(".ytp-play-button");

      if (!playButton) {
        throw error;
      }

      playButton.click();
      await new Promise((resolve) => window.setTimeout(resolve, 120));

      if (video.paused) {
        throw error;
      }
    }
  }

  async function clickPlayerButton(selectors, options = {}) {
    const button = selectors.map((selector) => document.querySelector(selector)).find(Boolean);

    if (!button) {
      if (options.optional) {
        return false;
      }

      throw new Error("YouTube player button not found");
    }

    button.click();
    await new Promise((resolve) => window.setTimeout(resolve, 180));
    return true;
  }

  async function clickFirstVideoResult() {
    const selectors = [
      "a#video-title[href*='/watch?v=']",
      "ytd-video-renderer a#thumbnail[href*='/watch?v=']",
      "a.yt-lockup-metadata-view-model__title[href*='/watch?v=']",
      "a[href*='/watch?v=']"
    ];
    const link = selectors.map((selector) => document.querySelector(selector)).find(Boolean);

    if (!link) {
      throw new Error("No video result found");
    }

    link.click();
    await new Promise((resolve) => window.setTimeout(resolve, 300));
  }

  async function draftComment(text) {
    const cleanText = String(text || "").trim();

    if (!cleanText) {
      throw new Error("Say comment followed by the comment text");
    }

    const comments = document.querySelector("ytd-comments") || document.querySelector("#comments");
    if (comments) {
      comments.scrollIntoView({ block: "center", behavior: "smooth" });
    } else {
      window.scrollBy({ top: Math.max(window.innerHeight * 0.8, 500), behavior: "smooth" });
    }

    await wait(700);

    const placeholder = await waitForElement([
      "ytd-comment-simplebox-renderer #placeholder-area",
      "ytd-comment-simplebox-renderer #simplebox-placeholder",
      "ytd-comments #placeholder-area",
      "ytd-comments #simplebox-placeholder",
      "#comments #placeholder-area",
      "#comments #simplebox-placeholder"
    ], 3000);

    if (placeholder) {
      placeholder.click();
      await wait(350);
    }

    const editor = await waitForElement([
      "ytd-commentbox #contenteditable-root[contenteditable='true']",
      "ytd-comment-simplebox-renderer #contenteditable-root[contenteditable='true']",
      "#comments #contenteditable-root[contenteditable='true']",
      "div[contenteditable='true'][aria-label*='comment' i]"
    ], 2400);

    if (!editor) {
      throw new Error("Comment box not found. You may need to sign in or open a video page.");
    }

    fillEditable(editor, cleanText);
  }

  async function setReaction(reaction) {
    const button = findReactionButton(reaction);

    if (!button) {
      throw new Error(`${reaction === "like" ? "Like" : "Dislike"} button not found`);
    }

    if (isPressed(button)) {
      return reaction === "like" ? "Already liked" : "Already disliked";
    }

    button.click();
    await wait(250);
    return reaction === "like" ? "Like" : "Dislike";
  }

  async function setFullscreen(enabled) {
    const button = document.querySelector(".ytp-fullscreen-button");

    if (!button) {
      throw new Error("Fullscreen button not found");
    }

    const isFull = Boolean(document.fullscreenElement) ||
      Boolean(document.querySelector(".html5-video-player.ytp-fullscreen"));

    if (isFull === enabled) {
      return enabled ? "Already fullscreen" : "Fullscreen already closed";
    }

    button.click();
    await wait(250);
    return enabled ? "Fullscreen" : "Exit fullscreen";
  }

  function setLoop(video, enabled) {
    if (loopVideo && loopReplayHandler) {
      loopVideo.removeEventListener("ended", loopReplayHandler);
    }

    video.loop = Boolean(enabled);
    loopVideo = enabled ? video : null;
    loopReplayHandler = null;

    if (!enabled) {
      return;
    }

    loopReplayHandler = () => {
      video.currentTime = 0;
      playVideo(video).catch(() => {});
    };
    video.addEventListener("ended", loopReplayHandler);
  }

  async function setCaptions(enabled) {
    const button = document.querySelector(".ytp-subtitles-button");

    if (!button) {
      throw new Error("Captions button not found for this video");
    }

    const isOn = button.getAttribute("aria-pressed") === "true" ||
      button.classList.contains("ytp-button-active");

    if (isOn === enabled) {
      return enabled ? "Captions already on" : "Captions already off";
    }

    button.click();
    await wait(200);
    return enabled ? "Captions on" : "Captions off";
  }

  async function setSubscription(enabled) {
    const button = findSubscriptionButton();

    if (!button) {
      throw new Error("Subscribe button not found");
    }

    const state = getSubscriptionState(button);

    if (enabled) {
      if (state === "subscribed") {
        return "Already subscribed";
      }

      button.click();
      await wait(500);
      return "Subscribe";
    }

    if (state !== "subscribed") {
      return "Already unsubscribed";
    }

    button.click();
    await wait(450);

    const menuUnsubscribe = findClickableByLabel(document, ["unsubscribe"], ["cancel"]);
    if (menuUnsubscribe) {
      menuUnsubscribe.click();
      await wait(450);
    }

    const confirmUnsubscribe = findClickableByLabel(document, ["unsubscribe"], ["cancel"]);
    if (confirmUnsubscribe && confirmUnsubscribe !== menuUnsubscribe) {
      confirmUnsubscribe.click();
      await wait(450);
    }

    return "Unsubscribe";
  }

  function findReactionButton(reaction) {
    const roots = getExistingRoots([
      "ytd-watch-metadata #actions",
      "ytd-watch-metadata #top-level-buttons-computed",
      "#top-level-buttons-computed",
      "#actions",
      "#menu-container"
    ]);
    const includes = reaction === "like"
      ? ["like this video", "i like this", "like"]
      : ["dislike this video", "i dislike this", "dislike"];
    const excludes = reaction === "like" ? ["dislike"] : [];

    return roots
      .map((root) => findClickableByLabel(root, includes, excludes))
      .find(Boolean) || null;
  }

  function findSubscriptionButton() {
    const direct = findFirstElement([
      "ytd-watch-metadata #subscribe-button button",
      "ytd-watch-metadata ytd-subscribe-button-renderer button",
      "#subscribe-button button",
      "ytd-subscribe-button-renderer button"
    ]);

    if (direct) {
      return direct;
    }

    return findClickableByLabel(document, ["subscribe", "subscribed"], ["unsubscribe"]);
  }

  function getSubscriptionState(button) {
    const label = getElementLabel(button);

    if (label.includes("subscribed")) {
      return "subscribed";
    }

    if (label.includes("subscribe")) {
      return "unsubscribed";
    }

    return "unknown";
  }

  function findClickableByLabel(root, includes, excludes = []) {
    const candidates = Array.from(root.querySelectorAll([
      "button",
      "[role='button']",
      "tp-yt-paper-button",
      "yt-button-shape button",
      "ytd-toggle-button-renderer"
    ].join(",")));

    return candidates.find((candidate) => {
      if (!isVisible(candidate)) {
        return false;
      }

      const label = getElementLabel(candidate);
      return includes.some((part) => label.includes(part)) &&
        !excludes.some((part) => label.includes(part));
    }) || null;
  }

  function getExistingRoots(selectors) {
    const roots = selectors
      .map((selector) => document.querySelector(selector))
      .filter(Boolean);

    return roots.length ? roots : [document];
  }

  function findFirstElement(selectors, root = document) {
    return selectors.map((selector) => root.querySelector(selector)).find(Boolean) || null;
  }

  async function waitForElement(selectors, timeout = 2000) {
    const startedAt = Date.now();

    while (Date.now() - startedAt < timeout) {
      const element = findFirstElement(selectors);

      if (element) {
        return element;
      }

      await wait(120);
    }

    return null;
  }

  function fillEditable(editor, text) {
    editor.focus();
    editor.textContent = "";

    const selection = window.getSelection && window.getSelection();
    if (selection && document.createRange) {
      const range = document.createRange();
      range.selectNodeContents(editor);
      range.collapse(false);
      selection.removeAllRanges();
      selection.addRange(range);
    }

    let inserted = false;
    if (document.execCommand) {
      inserted = document.execCommand("insertText", false, text);
    }

    if (!inserted) {
      editor.textContent = text;
    }

    const inputEvent = typeof InputEvent === "function"
      ? new InputEvent("input", { bubbles: true, data: text, inputType: "insertText" })
      : new Event("input", { bubbles: true });
    editor.dispatchEvent(inputEvent);
    editor.dispatchEvent(new Event("change", { bubbles: true }));
  }

  function getElementLabel(element) {
    return [
      element.getAttribute("aria-label"),
      element.getAttribute("title"),
      element.textContent
    ].filter(Boolean).join(" ").replace(/\s+/g, " ").trim().toLowerCase();
  }

  function isPressed(element) {
    const pressedElement = element.closest("[aria-pressed], [aria-checked]") || element;
    return pressedElement.getAttribute("aria-pressed") === "true" ||
      pressedElement.getAttribute("aria-checked") === "true";
  }

  function isVisible(element) {
    const rect = element.getBoundingClientRect();
    const style = window.getComputedStyle(element);
    return rect.width > 0 &&
      rect.height > 0 &&
      style.display !== "none" &&
      style.visibility !== "hidden";
  }

  function wait(ms) {
    return new Promise((resolve) => window.setTimeout(resolve, ms));
  }

  function getVideo() {
    return document.querySelector("video.html5-main-video") || document.querySelector("video");
  }

  function getVideoState() {
    const video = getVideo();
    const url = new URL(location.href);

    return {
      title: getTitle(),
      url: location.href,
      videoId: getVideoId(url),
      hasVideo: Boolean(video),
      paused: video ? video.paused : true,
      muted: video ? video.muted : false,
      currentTime: video ? Math.floor(video.currentTime || 0) : 0,
      duration: video && Number.isFinite(video.duration) ? Math.floor(video.duration) : 0,
      volume: video ? Math.round(video.volume * 100) : 0,
      playbackRate: video ? video.playbackRate : 1
    };
  }

  function getTitle() {
    const heading = document.querySelector("h1.ytd-watch-metadata yt-formatted-string") ||
      document.querySelector("h1 yt-formatted-string") ||
      document.querySelector("h1");

    if (heading && heading.textContent.trim()) {
      return heading.textContent.trim();
    }

    return document.title.replace(/\s*-\s*YouTube\s*$/i, "").trim() || "YouTube video";
  }

  function getVideoId(url) {
    if (url.hostname.includes("youtu.be")) {
      return url.pathname.split("/").filter(Boolean)[0] || null;
    }

    if (url.searchParams.has("v")) {
      return url.searchParams.get("v");
    }

    const pathMatch = url.pathname.match(/^\/(?:shorts|live|embed)\/([^/?#]+)/);
    return pathMatch ? pathMatch[1] : null;
  }

  function getDuration(video) {
    return Number.isFinite(video.duration) && video.duration > 0 ? video.duration : video.currentTime;
  }

  function clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
  }

  function formatTime(totalSeconds) {
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = Math.floor(totalSeconds % 60).toString().padStart(2, "0");
    return `${minutes}:${seconds}`;
  }
})();
