const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");
const test = require("node:test");
const vm = require("node:vm");

const extensionDir = __dirname;

function createElementStub() {
  return {
    children: [],
    className: "",
    disabled: false,
    lastElementChild: null,
    textContent: "",
    value: "",
    addEventListener() {},
    append() {},
    prepend() {},
    remove() {},
    setAttribute() {},
    classList: {
      add() {},
      remove() {}
    }
  };
}

function loadParseCommand() {
  const sandbox = {
    URL,
    console,
    location: { pathname: "/popup.html" },
    navigator: {},
    document: {
      createElement() {
        return createElementStub();
      },
      querySelector() {
        return createElementStub();
      }
    },
    chrome: {
      runtime: {
        getURL(file) {
          return `chrome-extension://${file}`;
        }
      },
      scripting: {
        async executeScript() {}
      },
      tabs: {
        async create() {
          return {};
        },
        async goBack() {},
        async query() {
          return [];
        },
        async sendMessage() {
          return { ok: true, state: {} };
        },
        async update() {
          return {};
        }
      }
    },
    window: {
      setTimeout() {
        return 0;
      }
    }
  };

  sandbox.globalThis = sandbox;
  sandbox.window.window = sandbox.window;
  sandbox.window.location = sandbox.location;

  const commandParserPath = path.join(extensionDir, "command-parser.js");
  if (fs.existsSync(commandParserPath)) {
    vm.runInNewContext(fs.readFileSync(commandParserPath, "utf8"), sandbox, { filename: commandParserPath });
  }

  const popupPath = path.join(extensionDir, "popup.js");
  vm.runInNewContext(fs.readFileSync(popupPath, "utf8"), sandbox, { filename: popupPath });

  assert.equal(typeof sandbox.parseCommand, "function");
  return sandbox.parseCommand;
}

function plain(value) {
  return JSON.parse(JSON.stringify(value));
}

test("parses comment commands as review-only drafts", () => {
  const parseCommand = loadParseCommand();
  const action = parseCommand("comment this lesson is clear");

  assert.equal(action.type, "comment");
  assert.equal(action.text, "this lesson is clear");
  assert.equal(action.label, "Comment draft");
});

test("parses like and dislike commands", () => {
  const parseCommand = loadParseCommand();

  assert.deepEqual(plain(parseCommand("like video")), {
    type: "setReaction",
    reaction: "like",
    label: "Like"
  });
  assert.deepEqual(plain(parseCommand("dislike")), {
    type: "setReaction",
    reaction: "dislike",
    label: "Dislike"
  });
});

test("parses fullscreen commands", () => {
  const parseCommand = loadParseCommand();

  assert.deepEqual(plain(parseCommand("fullscreen")), {
    type: "fullscreen",
    enabled: true,
    label: "Fullscreen"
  });
  assert.deepEqual(plain(parseCommand("exit full screen")), {
    type: "fullscreen",
    enabled: false,
    label: "Exit fullscreen"
  });
});

test("parses loop commands", () => {
  const parseCommand = loadParseCommand();

  assert.deepEqual(plain(parseCommand("loop video")), {
    type: "loop",
    enabled: true,
    label: "Loop on"
  });
  assert.deepEqual(plain(parseCommand("stop loop")), {
    type: "loop",
    enabled: false,
    label: "Loop off"
  });
});

test("parses subtitles and captions commands", () => {
  const parseCommand = loadParseCommand();

  assert.deepEqual(plain(parseCommand("open subtitles")), {
    type: "captions",
    enabled: true,
    label: "Captions on"
  });
  assert.deepEqual(plain(parseCommand("close subtleties")), {
    type: "captions",
    enabled: false,
    label: "Captions off"
  });
});

test("parses subscribe and unsubscribe commands distinctly", () => {
  const parseCommand = loadParseCommand();

  assert.deepEqual(plain(parseCommand("subscribe")), {
    type: "subscription",
    enabled: true,
    label: "Subscribe"
  });
  assert.deepEqual(plain(parseCommand("unsubscribe")), {
    type: "subscription",
    enabled: false,
    label: "Unsubscribe"
  });
});

test("parses account page navigation commands", () => {
  const parseCommand = loadParseCommand();

  assert.deepEqual(plain(parseCommand("open account page")), {
    type: "navigate",
    label: "Account page",
    url: "https://www.youtube.com/account"
  });
});

test("keeps existing playback, search, and volume commands", () => {
  const parseCommand = loadParseCommand();

  assert.deepEqual(plain(parseCommand("play")), {
    type: "play",
    label: "Play"
  });
  assert.deepEqual(plain(parseCommand("play never gonna give you up")), {
    type: "playSearch",
    label: "Play: never gonna give you up",
    query: "never gonna give you up"
  });
  assert.deepEqual(plain(parseCommand("search video jazz")), {
    type: "navigate",
    label: "Search: jazz",
    url: "https://www.youtube.com/results?search_query=jazz"
  });
  assert.deepEqual(plain(parseCommand("volume fifty")), {
    type: "volumeTo",
    volume: 50,
    label: "Volume 50"
  });
});
