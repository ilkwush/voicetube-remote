# VoiceTube Remote Chrome Extension

This is the unpacked Chrome extension version of VoiceTube Remote. It controls the real YouTube tab directly instead of embedding YouTube in a local page.

## Install

1. Open `chrome://extensions/`.
2. Turn on `Developer mode`.
3. Click `Load unpacked`.
4. Select this folder: `chrome-extension`.
5. Open a YouTube video tab.
6. Click the VoiceTube Remote extension icon.
7. Click `Open full remote` for the most reliable microphone behavior.

Keep the popup or full remote tab open while using voice control. Chrome stops popup scripts when the popup closes, so the full remote tab is better for longer sessions.

## Commands

- `play`
- `play never gonna give you up`
- `pause`
- `next video`
- `previous video`
- `mute`
- `unmute`
- `forward thirty`
- `back fifteen`
- `volume fifty`
- `faster`
- `slower`
- `normal speed`
- `restart`
- `comment great lesson`
- `like video`
- `dislike`
- `fullscreen`
- `exit fullscreen`
- `loop video`
- `stop loop`
- `open subtitles`
- `close subtitles`
- `subscribe`
- `unsubscribe`
- `open account page`
- `go to main page`
- `search video jazz`

`comment ...` fills the YouTube comment box as a draft for review. It does not post the comment automatically.
