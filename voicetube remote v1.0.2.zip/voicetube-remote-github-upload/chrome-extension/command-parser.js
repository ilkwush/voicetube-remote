(function exposeVoiceTubeCommands(root) {
  const SMALL_NUMBER_WORDS = {
    zero: 0,
    one: 1,
    two: 2,
    three: 3,
    four: 4,
    five: 5,
    six: 6,
    seven: 7,
    eight: 8,
    nine: 9,
    ten: 10,
    eleven: 11,
    twelve: 12,
    thirteen: 13,
    fourteen: 14,
    fifteen: 15,
    sixteen: 16,
    seventeen: 17,
    eighteen: 18,
    nineteen: 19
  };

  const TENS_NUMBER_WORDS = {
    twenty: 20,
    thirty: 30,
    forty: 40,
    fourty: 40,
    fifty: 50,
    sixty: 60,
    seventy: 70,
    eighty: 80,
    ninety: 90
  };

  function parseVoiceCommand(rawCommand) {
    const command = normalizeCommand(rawCommand);

    if (!command) {
      return null;
    }

    if (matches(command, [
      "open account",
      "open account page",
      "account",
      "account page",
      "my account",
      "youtube account",
      "open youtube account",
      "settings page",
      "open settings"
    ])) {
      return {
        type: "navigate",
        label: "Account page",
        url: "https://www.youtube.com/account"
      };
    }

    if (matches(command, [
      "home",
      "main",
      "main page",
      "youtube home",
      "go home",
      "go to home",
      "home page",
      "go to main page",
      "open youtube",
      "open main page",
      "youtube main page"
    ])) {
      return {
        type: "navigate",
        label: "YouTube home",
        url: "https://www.youtube.com/"
      };
    }

    const commentMatch = command.match(/^(?:comment|leave comment|write comment|draft comment|add comment)\s+(.+)/);
    if (commentMatch) {
      const text = commentMatch[1].trim();
      if (text) {
        return { type: "comment", text, label: "Comment draft" };
      }
    }

    const loadMatch = command.match(/(?:load|open|play video)\s+(.+)/);
    if (loadMatch) {
      const video = parseVideoInput(loadMatch[1]);
      if (video) {
        return {
          type: "navigate",
          label: `Open ${video.id}`,
          url: getYouTubeWatchUrl(video)
        };
      }
    }

    const playNamedMatch = command.match(/^play\s+(.+)/);
    if (playNamedMatch) {
      const query = cleanSearchQuery(playNamedMatch[1]);
      const video = parseVideoInput(query);

      if (video) {
        return {
          type: "navigate",
          label: `Open ${video.id}`,
          url: getYouTubeWatchUrl(video)
        };
      }

      if (query) {
        return {
          type: "playSearch",
          label: `Play: ${query}`,
          query
        };
      }
    }

    const searchMatch = command.match(/(?:search video|search(?: for)?|find(?: video)?|look up)\s+(.+)/);
    if (searchMatch) {
      const query = cleanSearchQuery(searchMatch[1]);
      if (query) {
        return {
          type: "navigate",
          label: `Search: ${query}`,
          url: getYouTubeSearchUrl(query)
        };
      }
    }

    if (matches(command, ["unsubscribe", "unsub", "unsubscribe channel", "stop subscription"])) {
      return { type: "subscription", enabled: false, label: "Unsubscribe" };
    }

    if (matches(command, ["subscribe", "subscribe channel", "follow channel"])) {
      return { type: "subscription", enabled: true, label: "Subscribe" };
    }

    if (matches(command, ["dislike", "dislike video", "thumbs down"])) {
      return { type: "setReaction", reaction: "dislike", label: "Dislike" };
    }

    if (matches(command, ["like", "like video", "thumbs up"])) {
      return { type: "setReaction", reaction: "like", label: "Like" };
    }

    if (matches(command, [
      "exit fullscreen",
      "exit full screen",
      "leave fullscreen",
      "leave full screen",
      "close fullscreen",
      "close full screen"
    ])) {
      return { type: "fullscreen", enabled: false, label: "Exit fullscreen" };
    }

    if (matches(command, ["fullscreen", "full screen", "enter fullscreen", "enter full screen"])) {
      return { type: "fullscreen", enabled: true, label: "Fullscreen" };
    }

    if (matches(command, ["stop loop", "loop off", "repeat off", "disable loop", "turn off loop"])) {
      return { type: "loop", enabled: false, label: "Loop off" };
    }

    if (matches(command, ["loop", "loop video", "repeat", "repeat video", "turn on loop"])) {
      return { type: "loop", enabled: true, label: "Loop on" };
    }

    if (matches(command, [
      "subtitles off",
      "subtitle off",
      "captions off",
      "caption off",
      "cc off",
      "close subtitles",
      "close subtitle",
      "close captions",
      "close caption",
      "close subtleties",
      "subtleties off"
    ])) {
      return { type: "captions", enabled: false, label: "Captions off" };
    }

    if (matches(command, [
      "subtitles on",
      "subtitle on",
      "captions on",
      "caption on",
      "cc on",
      "open subtitles",
      "open subtitle",
      "open captions",
      "open caption",
      "open subtleties",
      "subtleties on"
    ])) {
      return { type: "captions", enabled: true, label: "Captions on" };
    }

    if (matchesExact(command, ["play", "resume", "start", "start video"])) {
      return { type: "play", label: "Play" };
    }

    if (matches(command, ["next video", "next", "skip video", "skip to next"])) {
      return { type: "nextVideo", label: "Next video" };
    }

    if (matches(command, ["previous video", "previous", "prev video", "last video", "go back video"])) {
      return { type: "browserBack", label: "Previous video" };
    }

    if (matches(command, ["pause", "hold", "stop video"])) {
      return { type: "pause", label: "Pause" };
    }

    if (matches(command, ["toggle", "play pause"])) {
      return { type: "toggle", label: "Toggle play" };
    }

    if (matches(command, ["mute", "silent"])) {
      return { type: "mute", label: "Mute" };
    }

    if (matches(command, ["unmute", "sound on"])) {
      return { type: "unmute", label: "Unmute" };
    }

    if (matches(command, ["restart", "start over", "beginning"])) {
      return { type: "restart", label: "Restart" };
    }

    if (matches(command, ["faster", "speed up"])) {
      return { type: "rateBy", delta: 0.25, label: "Speed up" };
    }

    if (matches(command, ["slower", "slow down"])) {
      return { type: "rateBy", delta: -0.25, label: "Slow down" };
    }

    if (matches(command, ["normal speed", "regular speed"])) {
      return { type: "rateTo", rate: 1, label: "Normal speed" };
    }

    if (command.includes("volume up") || command.includes("louder")) {
      return { type: "volumeBy", delta: 0.1, label: "Volume up" };
    }

    if (command.includes("volume down") || command.includes("quieter")) {
      return { type: "volumeBy", delta: -0.1, label: "Volume down" };
    }

    const volumeMatch = command.match(/(?:volume|sound)\s*(?:to|at)?\s*([a-z\d -]+)/);
    if (volumeMatch) {
      const volume = parseSpokenNumber(volumeMatch[1]);
      if (volume !== null) {
        return { type: "volumeTo", volume: clamp(volume, 0, 100), label: `Volume ${volume}` };
      }
    }

    const forwardMatch = command.match(/(?:forward|ahead|skip)(?:\s+([a-z\d -]+))?/);
    if (forwardMatch) {
      const seconds = parseSpokenNumber(forwardMatch[1]) || 10;
      return { type: "seekBy", seconds, label: `Forward ${seconds}s` };
    }

    const backMatch = command.match(/(?:back|rewind|backward)(?:\s+([a-z\d -]+))?/);
    if (backMatch) {
      const seconds = parseSpokenNumber(backMatch[1]) || 10;
      return { type: "seekBy", seconds: -seconds, label: `Back ${seconds}s` };
    }

    const seekMatch = command.match(/(?:go to|jump to|seek to)\s+(.+)/);
    if (seekMatch) {
      const seconds = parseTime(seekMatch[1]);
      if (seconds !== null) {
        return { type: "seekTo", seconds, label: `Seek ${formatTime(seconds)}` };
      }
    }

    return null;
  }

  function normalizeCommand(value) {
    return String(value || "").toLowerCase().replace(/[^\w\s:/.-]/g, "").trim();
  }

  function matches(command, phrases) {
    return phrases.some((phrase) => command === phrase || command.includes(phrase));
  }

  function matchesExact(command, phrases) {
    return phrases.some((phrase) => command === phrase);
  }

  function parseVideoInput(input) {
    const value = input.trim();

    if (/^[a-zA-Z0-9_-]{11}$/.test(value)) {
      return { id: value, startSeconds: 0 };
    }

    try {
      const url = new URL(value);
      let id = null;

      if (url.hostname.includes("youtu.be")) {
        id = url.pathname.split("/").filter(Boolean)[0] || null;
      } else if (url.searchParams.has("v")) {
        id = url.searchParams.get("v");
      } else {
        const pathMatch = url.pathname.match(/\/(?:embed|shorts|live)\/([a-zA-Z0-9_-]{11})/);
        id = pathMatch ? pathMatch[1] : null;
      }

      return id ? { id, startSeconds: parseStartSeconds(url) } : null;
    } catch (error) {
      return null;
    }
  }

  function parseStartSeconds(url) {
    const rawStart = url.searchParams.get("start") || url.searchParams.get("t") || "";
    const hashStart = url.hash.startsWith("#t=") ? url.hash.slice(3) : "";
    return parseTime(rawStart || hashStart) || 0;
  }

  function getYouTubeWatchUrl(video) {
    const url = new URL(`https://www.youtube.com/watch?v=${video.id}`);

    if (video.startSeconds) {
      url.searchParams.set("t", `${Math.floor(video.startSeconds)}s`);
    }

    return url.toString();
  }

  function getYouTubeSearchUrl(query) {
    const url = new URL("https://www.youtube.com/results");
    url.searchParams.set("search_query", query);
    return url.toString();
  }

  function cleanSearchQuery(query) {
    return query
      .replace(/\b(on youtube|youtube|please)\b/gi, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  function parseTime(value) {
    if (!value) {
      return null;
    }

    const cleanValue = String(value).trim();
    const colonParts = cleanValue.split(":").map(Number);

    if (colonParts.length > 1 && colonParts.every((part) => Number.isFinite(part))) {
      return colonParts.reduce((total, part) => total * 60 + part, 0);
    }

    const minuteSecondMatch = cleanValue.match(/(?:(\d+)\s*(?:hours?|hrs?|h))?\s*(?:(\d+)\s*(?:minutes?|mins?|m))?\s*(?:(\d+)\s*(?:seconds?|secs?|s))?/);
    if (minuteSecondMatch && (minuteSecondMatch[1] || minuteSecondMatch[2] || minuteSecondMatch[3])) {
      return Number(minuteSecondMatch[1] || 0) * 3600 +
        Number(minuteSecondMatch[2] || 0) * 60 +
        Number(minuteSecondMatch[3] || 0);
    }

    const numeric = Number(cleanValue);
    if (Number.isFinite(numeric)) {
      return numeric;
    }

    return parseSpokenNumber(cleanValue);
  }

  function parseSpokenNumber(value) {
    if (!value) {
      return null;
    }

    const cleanValue = String(value).toLowerCase().replace(/-/g, " ").replace(/\band\b/g, " ").trim();
    const numeric = Number(cleanValue);
    if (Number.isFinite(numeric)) {
      return numeric;
    }

    const words = cleanValue.split(/\s+/).filter(Boolean);
    if (!words.length) {
      return null;
    }

    let current = 0;
    let matched = false;

    words.forEach((word) => {
      if (Object.prototype.hasOwnProperty.call(SMALL_NUMBER_WORDS, word)) {
        current += SMALL_NUMBER_WORDS[word];
        matched = true;
      } else if (Object.prototype.hasOwnProperty.call(TENS_NUMBER_WORDS, word)) {
        current += TENS_NUMBER_WORDS[word];
        matched = true;
      } else if (word === "hundred") {
        current = (current || 1) * 100;
        matched = true;
      }
    });

    return matched ? current : null;
  }

  function formatTime(totalSeconds) {
    const cleanSeconds = Math.max(0, Number(totalSeconds) || 0);
    const hours = Math.floor(cleanSeconds / 3600);
    const minutes = Math.floor((cleanSeconds % 3600) / 60);
    const seconds = Math.floor(cleanSeconds % 60).toString().padStart(2, "0");

    if (hours) {
      return `${hours}:${minutes.toString().padStart(2, "0")}:${seconds}`;
    }

    return `${minutes}:${seconds}`;
  }

  function clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
  }

  const api = {
    cleanSearchQuery,
    getYouTubeSearchUrl,
    getYouTubeWatchUrl,
    normalizeCommand,
    parseSpokenNumber,
    parseTime,
    parseVideoInput,
    parseVoiceCommand
  };

  if (typeof module !== "undefined" && module.exports) {
    module.exports = api;
  }

  root.VoiceTubeCommands = api;

  if (root.window && root.window !== root) {
    root.window.VoiceTubeCommands = api;
  }
})(typeof globalThis !== "undefined" ? globalThis : window);
